/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.payroll.system;

/**
 *
 * @author Hyrex
 */

import java.sql.*;
import javax.swing.*;
public class db {
    
    private  static db c =  null ;
    public static Connection conn ;
   // public Statement stmt = null;
    public static Connection java_db(){
        
        try{
            Class.forName("org.sqlite.JDBC");
             db.conn =DriverManager.getConnection("jdbc:sqlite:D:\\Employee Payroll System\\empnet.sqlite");
            return conn;
        //   stmt = conn.createStatement();
              
        }catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }   
    }
    public static db getConnection()
    {
        if (c==null)
        {
            c = new db();
        }
        return c;
    }
}

